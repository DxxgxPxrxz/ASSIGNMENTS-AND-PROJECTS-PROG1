
public class Main {

    public static void main(String[] args) {


        Striker Lionel = new Striker("Lionel", "Mexican", 19,10);
        Defender Puyol = new Defender("Puyol","Peruvian", 25, 35);
        Midfielder Busquets = new Midfielder("Busquets", "Spanish", 23, 7);
        Goalkeeper Neuer = new Goalkeeper("Neuer","Germany", 26, 1);

        Striker.give_data();



    }
}
